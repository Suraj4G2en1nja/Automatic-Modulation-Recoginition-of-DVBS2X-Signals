async function uploadFile() {

    const fileInput = document.getElementById("fileInput");

    if (!fileInput.files.length) {
        alert("Upload file");
        return;
    }

    const formData = new FormData();
    formData.append("file", fileInput.files[0]);
    formData.append("snr", document.getElementById("snrInput").value);

    const response = await fetch("/upload", {
        method: "POST",
        body: formData
    });

    const data = await response.json();

    renderStats(data);
    renderGraphs(data);

    document.getElementById("downloadBtn").style.display = "block";
}


/* ---------------- STATS ONLY ---------------- */
function renderStats(data) {

    // ✅ MODEL DISPLAY MAPPING (ONLY FRONTEND CHANGE)
    const modelMap = {
        "srfn": "AFR-Net",
        "lightgbm": "S-GBC"
    };

    document.getElementById("result").innerHTML = `
        <h3>📡 OUTPUT RESULTS</h3>

        <div class="label">Modulation</div><div class="box">${data.modulation}</div>
        <div class="label">Model</div>
        <div class="box">${modelMap[data.model?.toLowerCase()] || data.model}</div>
        <div class="label">Accuracy</div><div class="box">${data.accuracy}</div>
        <div class="label">SNR</div><div class="box">${data.snr}</div>

        <hr>

        <h4>📊 Statistical Features</h4>

        <div class="label">c21</div><div class="box">${data.c21}</div>
        <div class="label">c40</div><div class="box">${data.c40}</div>
        <div class="label">c42</div><div class="box">${data.c42}</div>
        <div class="label">Kurtosis</div><div class="box">${data.kurt}</div>
        <div class="label">Skewness</div><div class="box">${data.skew}</div>
    `;
}


/* ---------------- GRAPHS ---------------- */
function renderGraphs(data) {

    createChart("aChart", "Amplitude (a)", data.a_features);
    createChart("fChart", "Frequency (f)", data.f_features);
    createChart("sChart", "Spectrum (s)", data.s_features);
}

function createChart(id, label, arr) {

    new Chart(document.getElementById(id), {
        type: "line",
        data: {
            labels: arr.map((_, i) => i),
            datasets: [{
                label: label,
                data: arr,
                borderColor: "#00c3ff",
                fill: false,
                tension: 0.2
            }]
        },
        options: {
            plugins: { legend: { display: true } },
            scales: { x: { display: false } }
        }
    });
}


/* ---------------- DOWNLOAD ---------------- */
function downloadGraphs() {
    download("aChart", "a_features.png");
    download("fChart", "f_features.png");
    download("sChart", "s_features.png");
}

function download(canvasId, name) {
    const canvas = document.getElementById(canvasId);
    const link = document.createElement("a");
    link.download = name;
    link.href = canvas.toDataURL("image/png");
    link.click();
}